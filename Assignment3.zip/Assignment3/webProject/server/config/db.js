module.exports=
{
    "URI":"mongodb+srv://s_imran:Ehsun123@cluster0.kw8uqzb.mongodb.net/movieStore"
}